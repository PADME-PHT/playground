import psycopg2
import os

#Read in env vars (configuration)
db_user = os.environ["DATA_SOURCE_USERNAME"]
db_password = os.environ["DATA_SOURCE_PASSWORD"]
db_host = os.environ["DATA_SOURCE_HOST"]
db_port = os.environ["DATA_SOURCE_PORT"]

# This environment var is not provided by default and needs to be added!
station = os.environ["STATION_NAME"]

#Connect to DB
conn = psycopg2.connect(
  dbname="patientdb",
  user=db_user,
  host=db_host,
  password=db_password,
  port=db_port
)

#Execute query depending on result
if(station == "A"):
  cursor = conn.cursor()
  cursor.execute("select * from patient_info where age >= 50")
  result = cursor.fetchall()  
else:
  cursor = conn.cursor()
  cursor.execute("select * from patients where age >= 50")
  result = cursor.fetchall()
  
patientCount = len(result)


print(f"found: {patientCount} patients at {station}")

f = open("result.txt", "a")
f.write(f"{station}: {str(patientCount)} patients" + "\n")
f.close()