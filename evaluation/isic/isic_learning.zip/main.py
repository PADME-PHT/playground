import os
import os.path as osp
import numpy as np

import glob
import tqdm
import shutil
import pytz
import datetime

import torch
import torch.nn as nn
from torch.autograd import Variable
import torch
import torch.nn as nn
from torchvision.models import resnet
from fhirpy import SyncFHIRClient
import requests
from io import BytesIO
import numpy as np
import pandas as pd
from PIL import Image
from torch.utils.data import Dataset
import torchvision.transforms as transforms

class ISICDataset(Dataset):
    classes = {'NV': 0, 'MEL': 1, 'BKL': 2, 'DF': 3, 'SCC': 4, 'BCC': 5, 'VASC': 6, 'AK': 7}

    """ISIC dataset."""
    def __init__(self, fhir_server, fhir_port, split='train', input_size=256):
        """
        Args: 
            fhir_server (string): Address of FHIR Server.
            fhir_port (string): Port of FHIR Server.
        """
        self.fhir_server = fhir_server
        self.fhir_port = fhir_port
        self.split = split
        self.input_size = input_size
        # Create an instance
        client = SyncFHIRClient('http://{}:{}/fhir'.format(fhir_server, fhir_port))
        # Search for patients
        patients = client.resources('Patient')  # Return lazy search set
        patients_data = []
        for patient in patients:
            patient_birthDate = None
            try:
                patient_birthDate = patient.birthDate
            except:
                pass
            # patinet_id, gender, birthDate
            patients_data.append([patient.id, patient.gender, patient_birthDate])
        patients_df = pd.DataFrame(patients_data, columns=["patient_id", "gender", "birthDate"])
        # Search for media
        media_list = client.resources('Media').include('Patient', 'subject')
        media_data = []
        for media in media_list:
            media_bodySite = None
            media_reasonCode = None
            media_note = None
            try:
                media_bodySite = media.bodySite.text
            except:
                pass
            try:
                media_reasonCode = media.reasonCode[0].text
            except:
                pass
            try:
                media_note = media.note[0].text
            except:
                pass
            media_data.append([media.subject.id, media.id, media_bodySite, media_reasonCode, media_note, media.content.url])
        media_df = pd.DataFrame(media_data, columns=["patient_id", "media_id", "bodySite", "reasonCode", "note", "image_url"])
        self.data_df = pd.merge(patients_df, media_df, on='patient_id', how='outer')
        self.data_df = self.data_df[self.data_df['note'].notna()].reset_index()
        self.trans = transforms.Compose([transforms.RandomHorizontalFlip(),
                                         transforms.RandomVerticalFlip(),
                                         transforms.ColorJitter(brightness=32. / 255., saturation=0.5),
                                         transforms.Resize(self.input_size),
                                         transforms.ToTensor()])

    def __len__(self):
        if self.split == "train":
            return int(len(self.data_df) * 0.8)
        elif self.split == "val":
            return int(len(self.data_df) * 0.2)

    def __getitem__(self, idx):
        val_start_id = int(len(self.data_df) * 0.8)
        if self.split == "train":
            idx = idx
        else:
            idx = idx + val_start_id
        img_url = self.data_df.loc[idx, 'image_url']
        note = self.data_df.loc[idx, 'note']
        y = self.classes[note]
        img_res = requests.get(img_url)
        if img_res.status_code == 200:
            x = Image.open(BytesIO(img_res.content))
            x = self.center_crop(x)
            x = self.trans(x)
            # Transform y
            y = np.int64(y)
            return {"image": x, "label": y}
        else:
            raise RuntimeError("Image url {} is not reachable!".format(img_url))

    def center_crop(self, pil_img):
        img_width, img_height = pil_img.size
        if img_width > img_height:
            crop_size = img_height
        else:
            crop_size = img_width
        return pil_img.crop(((img_width - crop_size) // 2,
                             (img_height - crop_size) // 2,
                             (img_width + crop_size) // 2,
                             (img_height + crop_size) // 2))
class ISICNet(nn.Module):
    def __init__(self, n_feature=3, n_class=8):
        super(ISICNet, self).__init__()
        self.n_feature = n_feature
        self.n_class = n_class
        base = resnet.resnet18(pretrained=True)
        self.resnet_expansion = 1
        self.in_block = nn.Sequential(nn.Conv2d(self.n_feature, 64, kernel_size=(7, 7), stride=(2, 2), padding=(3, 3), bias=False),base.bn1,base.relu,base.maxpool)
        self.encoder1 = base.layer1
        self.encoder2 = base.layer2
        self.encoder3 = base.layer3
        self.encoder4 = base.layer4
        self.avgpool = base.avgpool
        self.flatten = nn.Flatten()
        self.fc = nn.Linear(512, self.n_class , bias=True)

    def forward(self, x):
        h = self.in_block(x)
        h = self.encoder1(h)
        h = self.encoder2(h)
        h = self.encoder3(h)
        h = self.encoder4(h)
        y = self.fc(self.flatten(self.avgpool(h)))
        return y

def _fast_hist(label_true, label_pred, n_class):
    hist = np.bincount(
        n_class * label_true.astype(int) +
        label_pred.astype(int), minlength=n_class ** 2).reshape(n_class, n_class)
    return hist

def label_accuracy_score(label_trues, label_preds, n_class=8):
    hist = np.zeros((n_class, n_class))
    hist += _fast_hist(label_trues, label_preds, n_class)
    acc = np.diag(hist).sum() / hist.sum()
    with np.errstate(divide='ignore', invalid='ignore'):
        precision = np.diag(hist) / hist.sum(axis=1)
    mean_precision = np.nanmean(precision)
    with np.errstate(divide='ignore', invalid='ignore'):
        recall = np.diag(hist) / hist.sum(axis=0)
    mean_recall = np.nanmean(recall)
    with np.errstate(divide='ignore', invalid='ignore'):
        iou = np.diag(hist) / (hist.sum(axis=1) + hist.sum(axis=0) - np.diag(hist))
    mean_iou = np.nanmean(iou)
    with np.errstate(divide='ignore', invalid='ignore'):
        f1 = (2 * np.diag(hist))/ (hist.sum(axis=1) + hist.sum(axis=0) + 2 * np.diag(hist))
    mean_f1 = np.nanmean(f1)
    return acc, mean_precision, mean_recall, mean_iou, mean_f1



## Define (input) variables from Docker Container environment variables
fhir_server = str(os.environ['FHIR_HOST_NAME'])
fhir_port = str(os.environ['FHIR_PORT'])
batch_size = int(os.environ.get('BATCH_SIZE', '1'))
lr = float(os.environ.get('LR', '0.01'))
weight_decay = float(os.environ.get('WEIGHT_DECAY', '0.005'))
station_name = os.environ["STATION_NAME"].replace(" ", "_")
path = f"/usr/src/app/{station_name}"
logsPath = f"/usr/src/app/{station_name}_logs"
if not os.path.exists(logsPath):
  os.makedirs(path)
  os.makedirs(logsPath)

cuda = torch.cuda.is_available()
torch.manual_seed(1337)
if cuda:
    torch.cuda.manual_seed(1337)

## Initial Model
model = ISICNet()

model_file_name = 'model.pth.tar'
fed_model_path = osp.join(path, model_file_name)

if osp.exists(fed_model_path):
    ## Load Model
    checkpoint = torch.load(fed_model_path)
    print("Loaded existing model")
    model.load_state_dict(checkpoint['state_dict'])
else: 
    print("Using initial model")

if cuda:
    print("Cuda:", cuda)
    model = model.cuda()
    
## Define (output) log file formats
print("Initial Log file")
if not osp.exists(osp.join(path, 'val_log.csv')):
    with open(osp.join(path, 'val_log.csv'), 'w') as f:
        header = ['Val_Loss', 'Acc', 'Precision', 'Recall', 'Iou', 'F1Score', 'Train_Loss', 'elapsed_time']
        header = map(str, header)
        f.write(','.join(header) + '\n')
        


## Initial Datasets of train and val on station 1, 2, 3 and test
kwargs = {'num_workers': 4, 'pin_memory': True} if cuda else {}
print("Initial Training Dataset")
train_dataloader = torch.utils.data.DataLoader(ISICDataset(fhir_server, fhir_port, split='train'), batch_size=batch_size, shuffle=True, **kwargs)
print("Initial Val Dataset")
val_dataloader = torch.utils.data.DataLoader(ISICDataset(fhir_server, fhir_port, split='val'), batch_size=batch_size, shuffle=False, **kwargs)
print("Initial Loss function")
criterion = nn.CrossEntropyLoss()
print("Initial Optimizer")
optim = torch.optim.SGD(model.parameters(), lr=lr, weight_decay=weight_decay)


timestamp_start = datetime.datetime.now(pytz.timezone('Asia/Tokyo'))
best_acc = 0.0
model.train()
train_loss = 0.0
for batch_idx, sample in enumerate(train_dataloader):
    assert model.training
    img, lbl = sample['image'], sample['label']
    if cuda:
        img, lbl = img.cuda(), lbl.cuda()
    img, lbl = Variable(img), Variable(lbl)
    optim.zero_grad()
    pred = model(img)
    loss = criterion(pred, lbl)
    train_loss = train_loss + loss.data.item()
    loss.backward()
    optim.step()

train_loss = train_loss / len(train_dataloader)
print("Learning finished with average train loss of {}.".format(train_loss))

model.eval()
val_loss = 0.0
label_trues, label_preds = [], []
for batch_idx, sample in enumerate(val_dataloader):
    img, lbl = sample['image'], sample['label']
    if cuda:
        img, lbl = img.cuda(), lbl.cuda()
    img, lbl = Variable(img), Variable(lbl)
    with torch.no_grad():
        pred = model(img)
    loss = criterion(pred, lbl)
    val_loss = val_loss + loss.data.item()
    lbl = lbl.data.cpu().numpy()
    pred = pred.data.max(1)[1].cpu().numpy()
    label_trues = np.concatenate((label_trues, lbl), axis=0)
    label_preds = np.concatenate((label_preds, pred), axis=0)
val_loss = val_loss / len(val_dataloader)
acc, mean_precision, mean_recall, mean_iou, mean_f1 = label_accuracy_score(label_trues, label_preds)
#Write header if file does not exist
path = osp.join(logsPath, 'val_log.csv')
if not osp.exists(path): 
    with open(path, 'a') as f:
        f.write('val_loss, acc, mean_precision, mean_recall, mean_iou, mean_f1, train_loss, elapsed_time \n')
#Append content
with open(path, 'a') as f:
    elapsed_time = (datetime.datetime.now(pytz.timezone('Asia/Tokyo')) - timestamp_start).total_seconds()
    log = [val_loss, acc, mean_precision, mean_recall, mean_iou, mean_f1, train_loss, elapsed_time]
    log = map(str, log)
    f.write(','.join(log) + '\n')
torch.save({'state_dict': model.state_dict()}, fed_model_path)
print("saved")
print(f"persistet model to: {fed_model_path}", flush=True)