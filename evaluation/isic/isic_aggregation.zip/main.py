import os
import os.path as osp
import numpy as np

import glob
from tqdm import tqdm
import shutil
import pytz
import datetime

import torch
import torch.nn as nn
from torch.autograd import Variable
import torch
import torch.nn as nn
from torchvision.models import resnet
from fhirpy import SyncFHIRClient
import requests
from io import BytesIO
import numpy as np
import pandas as pd
from PIL import Image
from torch.utils.data import Dataset
import torchvision.transforms as transforms
class ISICNet(nn.Module):
    def __init__(self, n_feature=3, n_class=8):
        super(ISICNet, self).__init__()
        self.n_feature = n_feature
        self.n_class = n_class
        base = resnet.resnet18(pretrained=True)
        self.resnet_expansion = 1
        self.in_block = nn.Sequential(nn.Conv2d(self.n_feature, 64, kernel_size=(7, 7), stride=(2, 2), padding=(3, 3), bias=False),base.bn1,base.relu,base.maxpool)
        self.encoder1 = base.layer1
        self.encoder2 = base.layer2
        self.encoder3 = base.layer3
        self.encoder4 = base.layer4
        self.avgpool = base.avgpool
        self.flatten = nn.Flatten()
        self.fc = nn.Linear(512, self.n_class , bias=True)

    def forward(self, x):
        h = self.in_block(x)
        h = self.encoder1(h)
        h = self.encoder2(h)
        h = self.encoder3(h)
        h = self.encoder4(h)
        y = self.fc(self.flatten(self.avgpool(h)))
        return y

def _fast_hist(label_true, label_pred, n_class):
    hist = np.bincount(
        n_class * label_true.astype(int) +
        label_pred.astype(int), minlength=n_class ** 2).reshape(n_class, n_class)
    return hist

def label_accuracy_score(label_trues, label_preds, n_class=8):
    hist = np.zeros((n_class, n_class))
    hist += _fast_hist(label_trues, label_preds, n_class)
    acc = np.diag(hist).sum() / hist.sum()
    with np.errstate(divide='ignore', invalid='ignore'):
        precision = np.diag(hist) / hist.sum(axis=1)
    mean_precision = np.nanmean(precision)
    with np.errstate(divide='ignore', invalid='ignore'):
        recall = np.diag(hist) / hist.sum(axis=0)
    mean_recall = np.nanmean(recall)
    with np.errstate(divide='ignore', invalid='ignore'):
        iou = np.diag(hist) / (hist.sum(axis=1) + hist.sum(axis=0) - np.diag(hist))
    mean_iou = np.nanmean(iou)
    with np.errstate(divide='ignore', invalid='ignore'):
        f1 = (2 * np.diag(hist))/ (hist.sum(axis=1) + hist.sum(axis=0) + 2 * np.diag(hist))
    mean_f1 = np.nanmean(f1)
    return acc, mean_precision, mean_recall, mean_iou, mean_f1
model = ISICNet()
models = []
aggregation_sources = "ISIC_Station_1,ISIC_Station_2,ISIC_Station_3"
for dir in aggregation_sources.split(","): 
    for file_name in os.listdir(dir):
        if file_name.endswith("pth.tar"):
            print(f"Loading {dir}/{file_name}")
            checkpoint = torch.load(f"{dir}/{file_name}")
            model = ISICNet()
            model.load_state_dict(checkpoint['state_dict'])
            models.append(model)

client_weights = [1.0/len(models) for _ in models]
for key in model.state_dict().keys():
    if 'num_batches_tracked' in key:
        model.state_dict()[key].data.copy_(models[0].state_dict()[key])
    else:
        temp = torch.zeros_like(model.state_dict()[key])
        for client_idx in range(len(client_weights)):
            temp += client_weights[client_idx] * models[client_idx].state_dict()[key]
        model.state_dict()[key].data.copy_(temp)

model_path = ""
torch.save({'state_dict': model.state_dict()}, f"{model_path}/model.pth.tar")
print("Aggregation finished")