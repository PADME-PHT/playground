import os
import os.path as osp
import torch

# List of station names
stations = ["UKA", "UKG", "UKK", "UKL", "IMISE", "Mittweida"]

# Load model and optimizer weights for each station
weights = [torch.load(osp.join(station, 'models', 'dnn.pth.tar')) for station in stations]

# Initialize aggregated weights
aggregated_model_weights = dict()

# Get the average of model and optimizer weights
num_stations = len(stations)
for station_weights in weights:
    for key, value in station_weights['model_state_dict'].items():
        if key not in aggregated_model_weights:
            aggregated_model_weights[key] = value / num_stations
        else:
            aggregated_model_weights[key] += value / num_stations
# Save the aggregated weights as a new checkpoint
aggregated_checkpoint_path = osp.join('aggregated_models', 'dnn.pth.tar')
if not osp.exists(osp.dirname(aggregated_checkpoint_path)):
    os.makedirs(osp.dirname(aggregated_checkpoint_path))

torch.save({
    'epoch': weights[0]['epoch'],
    'model_state_dict': aggregated_model_weights,
    'best_acc': sum([w['best_acc'] for w in weights]) / num_stations
}, aggregated_checkpoint_path)