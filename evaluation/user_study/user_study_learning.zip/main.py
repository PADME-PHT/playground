import psycopg2
import os

print("Welcome to the PADME Playground Eval!")
station_name = os.environ["STATION_NAME"]
print(station_name)

conn = psycopg2.connect(dbname="patientdb",
                        user=os.environ["DATA_SOURCE_USERNAME"],
                        host=os.environ["DATA_SOURCE_HOST"],
                        password=os.environ["DATA_SOURCE_PASSWORD"],
                        port=os.environ["DATA_SOURCE_PORT"])

cursor = conn.cursor()

cursor.execute(f"SELECT * FROM {'patient_info' if os.environ['STATION_NAME'] == 'Hospital A' else 'patients'} WHERE age >= 50")
result = cursor.fetchall()
nPatientsOver50 = len(result)
target = station_name.replace(" ", "_")
if not os.path.exists(target):
  os.makedirs(target)
f = open(f"{target}/result.txt", "a")
f.write(f"{nPatientsOver50}\n")
f.close()
