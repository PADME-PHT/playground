
hospital_dirs = ["Hospital_A", "Hospital_B"]
with open("aggregate_results.txt", "w") as aggregate:
        for hospital_dir in hospital_dirs:
            with open(f"{hospital_dir}/result.txt", "r") as file:
                patients_count = file.read()
                aggregate.write(f"{hospital_dir}: {patients_count}\n")
